const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const port = process.env.PORT || 8006;

const app = express();
app.use(bodyParser.json());
app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: false }));

mongoose
  .connect('mongodb://127.0.0.1:27017/signup', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    connectTimeoutMS: 30000,
    socketTimeoutMS: 30000,
  })
  .then(() => {
    console.log('Connection to MongoDB successful');
  })
  .catch((err) => {
    console.error('Error connecting to MongoDB:', err);
  });

const db = mongoose.connection;
db.on('error', (err) => {
  console.error('Error connecting to the database:', err);
});
db.once('open', () => {
  console.log('Connected to the database');
});

const userSchema = new mongoose.Schema({
  name: String,
  email: String,
  phone: String,
  password: String,
});

const User = mongoose.model('User', userSchema);

app.post('/signup', (req, res) => {
  const name = req.body.name;
  const phone = req.body.phone;
  const email = req.body.email;
  const password = req.body.password;

  // Hash the password before saving
  bcrypt.hash(password, 10, (err, hashedPassword) => {
    if (err) {
      console.error('Error hashing password:', err);
      return res.status(500).send('Error hashing password');
    }

    const newUser = new User({
      name: name,
      email: email,
      phone: phone,
      password: hashedPassword,
    });

    newUser
      .save()
      .then(() => {
        console.log('User saved successfully');
        return res.redirect('login.html');
      })
      .catch((err) => {
        console.error('Error saving user:', err);
        return res.status(500).send('Error saving user: ' + err.message);
      });
  });
});

app.post('/login', (req, res) => {
  const email = req.body.email;
  const password = req.body.password;

  User.findOne({ email: email })
    .then((user) => {
      if (!user) {
        console.log('Invalid email or password');
        return res.status(401).send('Invalid email or password');
      }

      // Compare the provided password with the hashed password in the database
      bcrypt.compare(password, user.password, (err, result) => {
        if (err || !result) {
          console.log('Invalid email or password');
          return res.status(401).send('Invalid email or password');
        } else {
          console.log('Login successful');
          return res.redirect('/kaif/index.html'); // Change the path to home.html
        }
      });
    })
    .catch((err) => {
      console.error('Error during login:', err);
      return res.status(500).send('Error during login: ' + err.message);
    });
});

app.get('/', (req, res) => {
  res.send('Hello from Kaif');
  return res.redirect('signup.html');
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
